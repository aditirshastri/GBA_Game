Game Overview and Controls:
Overview:
In this game the player will use the arrow keys to move a dart around
the screen with the aim of "popping" the balloon that is situated in
the bottom right corner of the screen. Although the dart only has
a point on one side, for simplicity's sake, the balloon will
"pop" if any part of the dart is touching it/has collided with it. The
player has 30 seconds to attempt to pop the balloon. If the balloon
is popped, the "WIN" screen shows up. If 30 seconds have passed
and the player has not popped the balloon, the "LOSE" screen appears.




Controls:
To start the game: ENTER
To return to the homescreen/initial screen at any point: BACKSPACE
To move the dart up: UP ARROW KEY
To move the dart down: DOWN ARROW KEY
To move the dart left: LEFT ARROW KEY
To move the dart right: RIGHT ARROW KEY

/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 dartpic dartpic.png 
 * Time-stamp: Monday 04/04/2022, 03:19:20
 * 
 * Image Information
 * -----------------
 * dartpic.png 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DARTPIC_H
#define DARTPIC_H

extern const unsigned short dartpic[400];
#define DARTPIC_SIZE 800
#define DARTPIC_LENGTH 400
#define DARTPIC_WIDTH 20
#define DARTPIC_HEIGHT 20

#endif


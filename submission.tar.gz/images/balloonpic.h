/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x50 balloonpic balloonpic.png 
 * Time-stamp: Monday 04/04/2022, 00:42:28
 * 
 * Image Information
 * -----------------
 * balloonpic.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BALLOONPIC_H
#define BALLOONPIC_H

extern const unsigned short balloonpic[2500];
#define BALLOONPIC_SIZE 5000
#define BALLOONPIC_LENGTH 2500
#define BALLOONPIC_WIDTH 50
#define BALLOONPIC_HEIGHT 50

#endif


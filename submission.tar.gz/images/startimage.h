/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 startimage startimage.png 
 * Time-stamp: Sunday 04/03/2022, 19:59:02
 * 
 * Image Information
 * -----------------
 * startimage.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTIMAGE_H
#define STARTIMAGE_H

extern const unsigned short startimage[38400];
#define STARTIMAGE_SIZE 76800
#define STARTIMAGE_LENGTH 38400
#define STARTIMAGE_WIDTH 240
#define STARTIMAGE_HEIGHT 160

#endif

